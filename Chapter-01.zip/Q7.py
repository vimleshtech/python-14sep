#python is indenation based language

a = int(input('enter num L'))
b   = int(input('enter num L'))
c = int(input('enter num L'))
d = int(input('enter num L'))

a=a**3
b=b**3
c=c**3
d=d**3

if a+b+c == d:
    print('condition is match')
else:
    print('condition is not match')


    

