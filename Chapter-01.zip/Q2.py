rno= input('enter rno')
name= input('enter name')

maths_marks=int( input('enter maths marks'))
eng_marks= int(input('enter eng marks'))
hindi_marks =int( input('enter hindi marks'))
sci_marks =int( input('enter sci marks'))
sst_marks =int( input('enter sst marks'))

print(rno)
print(name)
total = maths_marks+eng_marks+hindi_marks+sci_marks+sst_marks
avg = total/5

print(total)
print(avg)





