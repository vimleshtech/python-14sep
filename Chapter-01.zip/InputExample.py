#comments
#read data from user

n1 = input('enter data :') #default input type is str
n2 = input('enter data :')

print(n1)
print(n2)

print(type(n1))
print(type(n2))


n =int(n1) + int(n2) #convert str to int before add
print(n)


