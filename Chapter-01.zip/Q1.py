rno = input('enter rno')
name= input('enter name')
marks= input('enter marks')
phone = input('enter phone')


print(rno)
print(name)
print(marks)
print(phone)
