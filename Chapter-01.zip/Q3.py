a = int(input('value for a '))

square = a*a

print(square)
