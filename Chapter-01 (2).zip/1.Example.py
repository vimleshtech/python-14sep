a =110 #int
b   =55   #int 


c =a+b #expression 
print(c) #print/show output

