print('hi')
print('Raman')


print('hi',end='')
print('Raman')


##input from user

x = input('enter data :') 
n = input('enter name :')#default type is str 

print(type(x)) #print data type 
print(type(n))

print(x)
print(n)



