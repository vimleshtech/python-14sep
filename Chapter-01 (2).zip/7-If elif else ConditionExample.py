amt = int(input('enter sales amt:'))

tax = 0
if amt>10000:
    tax  = amt*.18 #18% of sale amt
elif amt>5000:
    tax = amt*.12
elif amt>1000:
    tax = amt*.05
else:
    tax = amt*.02
    


total = amt+tax
print(total)

