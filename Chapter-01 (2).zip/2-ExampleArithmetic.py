a =23

print(a*2)
print(a**3) #power
print(a/10)
print(a//10)
print(a%10)


n =1
print(n)

n+=10
print(n)
