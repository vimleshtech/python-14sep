n1 = int( input('enter data :') ) #input and type casting 
n2 = int( input('enter data :') )


o = n1+n2

print(o)


print('sum of n1 and n2 is o')

print('sum of n1 and n2 is ',o)

print('sum of ',n1,' and ',n2,' is ',o)

#or
print('sum of {} and {} is {}'.format(n1,n2,o))

print('sum of {1} and {0} is {2}'.format(n1,n2,o))


